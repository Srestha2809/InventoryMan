//export const BASEURL: string = 'http://localhost:8080/api';
//export const PDFURL = 'http://localhost:8080/ReportPDF?repid=';
export const BASEURL = '/api';
export const PDFURL = '/ReportPDF?repid=';