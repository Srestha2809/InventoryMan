import { ProductHomeComponent } from './product-home.component'

describe('ProductHomeComponent', () => {
  it('should mount', () => {
    cy.mount(ProductHomeComponent)
  })
})