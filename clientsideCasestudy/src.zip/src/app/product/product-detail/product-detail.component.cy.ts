import { ProductDetailComponent } from './product-detail.component'

describe('ProductDetailComponent', () => {
  it('should mount', () => {
    cy.mount(ProductDetailComponent)
  })
})