import { GeneratorComponent } from './generator.component'

describe('GeneratorComponent', () => {
  it('should mount', () => {
    cy.mount(GeneratorComponent)
  })
})