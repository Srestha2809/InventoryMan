export interface PurchaseItem {
    id: number;
    poid: number;
    productid: string;
    qty: number;
    price: number;
}
