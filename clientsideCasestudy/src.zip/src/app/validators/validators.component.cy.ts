import { ValidatorsComponent } from './validators.component'

describe('ValidatorsComponent', () => {
  it('should mount', () => {
    cy.mount(ValidatorsComponent)
  })
})