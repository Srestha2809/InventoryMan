import { Component } from '@angular/core';

@Component({
  selector: 'app-validators',
  template: `
    <p>
      validators works!
    </p>
  `,
  styleUrls: ['./validators.component.css']
})
export class ValidatorsComponent {

}
